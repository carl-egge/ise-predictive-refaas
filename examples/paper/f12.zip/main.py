import json

def count_employees(department):
    count = department.get('employees', 0)
    sub_departments = department.get('sub_departments', [])
    
    for sub_dept in sub_departments:
        count += count_employees(sub_dept)
    
    department['total_employees'] = count
    return count

def lambda_handler(event, context):

    try:
        body = json.loads(event.get('body'))
        org_structure = body.get('org_structure')

        if not org_structure:
            return {
                'statusCode': 400,
                'body': json.dumps({'error': 'Missing "org_structure" in request body.'})
            }

        for department in org_structure.get('departments', []):
            count_employees(department)

        return {
            'statusCode': 200,
            'body': json.dumps({'org_structure': org_structure})
        }

    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }