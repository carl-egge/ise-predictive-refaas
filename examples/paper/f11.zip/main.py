import json

def lambda_handler(event, context):

    try:
        body = json.loads(event.get('body', '{}'))

        user = body.get('user', {})
        name = user.get('name')
        email = user.get('contact', {}).get('email')

        if not name or not email:
            return {
                'statusCode': 400,
                'body': json.dumps({'error': 'Missing user information: name and email are required.'})
            }

        result = {
            'name': name,
            'email': email
        }

        return {
            'statusCode': 200,
            'body': json.dumps(result)
        }

    except json.JSONDecodeError:
        return {
            'statusCode': 400,
            'body': json.dumps({'error': 'Invalid JSON format.'})
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'error': 'Internal server error.'})
        }