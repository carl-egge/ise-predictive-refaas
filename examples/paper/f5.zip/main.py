import json

def compound_interest(event, context):
    principal = event.get('principal', 0)
    rate = event.get('rate', 0)
    time = event.get('time', 0)
    
    if principal <= 0 or rate < 0 or time < 0:
        return {
            'statusCode': 400,
            'body': json.dumps({'error': 'Invalid input'})
        }
    
    result = principal * ((1 + rate / 100) ** time)
    return {
        'statusCode': 200,
        'body': json.dumps({'result': result})
    }

def lambda_handler(event, context):
    return compound_interest(event, context)