import json
import requests
import logging

def lambda_handler(event, context):
    query_params = event.get('queryStringParameters', {})
    city = query_params.get('city')

    if not city:
        return {
            "statusCode": 400,
            "body": json.dumps({"error": "Missing 'city' query parameter."})
        }

    api_key = event.get('API_KEY') 
    if not api_key:
        return {
            "statusCode": 400,
            "body": json.dumps({"error": "Missing 'API_KEY' environment variable."})
        }
    api_url = f"http://api.openweathermap.org/data/2.5/weather?q={city}&appid={api_key}&units=metric"
    
    try:
        response = requests.get(api_url)
        response.raise_for_status()  
        weather_data = response.json()

        weather_description = weather_data['weather'][0]['description']
        temperature = weather_data['main']['temp']
        humidity = weather_data['main']['humidity']

        print(f"Fetched weather data for {city}: {weather_description}, {temperature}°C, {humidity}% humidity.")

        result = {
            "city": city,
            "weather_description": weather_description,
            "temperature_celsius": temperature,
            "humidity_percent": humidity
        }

        return {
            "statusCode": 200,
            "body": json.dumps(result)
        }

    except requests.exceptions.HTTPError as http_err:
        print(f"HTTP error occurred: {http_err}")
        return {
            "statusCode": response.status_code,
            "body": json.dumps({"error": "Failed to fetch weather data."})
        }
    except Exception as err:
        print(f"An error occurred: {err}")
        return {
            "statusCode": 500,
            "body": json.dumps({"error": "Internal server error."})
        }