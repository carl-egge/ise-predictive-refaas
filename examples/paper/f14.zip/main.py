from typing import Generator, Dict, Any, Callable, TypeVar, Iterator
from functools import wraps
from datetime import datetime
import inspect

T = TypeVar('T')

def validate_generator(func: Callable) -> Callable:
    @wraps(func)
    def wrapper(*args, **kwargs) -> Generator:
        sig = inspect.signature(func)
        bound_args = sig.bind(*args, **kwargs)
        bound_args.apply_defaults()
        
        data = bound_args.arguments.get('data', {})
        if not isinstance(data, dict) or not all(k in data for k in ['id', 'timestamp']):
            raise ValueError("Invalid input structure")
            
        gen = func(*args, **kwargs)
        
        def validated_generator() -> Generator[Dict[str, Any], None, None]:
            try:
                while True:
                    value = next(gen)
                    if not isinstance(value, dict):
                        raise TypeError("Generator must yield dictionaries")
                    yield value
            except StopIteration:
                return
                
        return validated_generator()
    return wrapper

class ComplexDataProcessor:
    
    def __init__(self):
        self.transformers: Dict[str, Callable] = {
            'reverse': lambda x: x[::-1],
            'uppercase': lambda x: x.upper() if isinstance(x, str) else x,
            'timestamp': lambda _: datetime.now().isoformat()
        }
    
    @validate_generator
    def process_complex_data(self, data: Dict[str, Any]) -> Generator[Dict[str, Any], None, None]:
   
        yield {
            'stage': 'id_transform',
            'value': self.transformers['reverse'](data['id']),
            'timestamp': self.transformers['timestamp'](None)
        }
    
        sequence = (
            {'index': i, 'value': self.transformers['uppercase'](str(i))}
            for i in range(3)
        )
        
        for item in sequence:
            yield {
                'stage': 'sequence',
                'data': item,
                'original_id': data['id'],
                'timestamp': self.transformers['timestamp'](None)
            }
        
        result = (lambda x: {
            'final': True,
            'transformed_id': f"PROC_{x['id']}",
            'metadata': {
                'original': x,
                'processTime': self.transformers['timestamp'](None)
            }
        })(data)
        
        yield result

def lambda_handler(event: Dict[str, Any], context=None) -> Dict[str, Any]:
    try:
        processor = ComplexDataProcessor()
        results = list(processor.process_complex_data(event))
        
        return {
            'status': 'success',
            'data': results,
            'metadata': {
                'processed_at': datetime.now().isoformat(),
                'stages_completed': len(results)
            }
        }
    except (ValueError, TypeError) as e:
        return {
            'status': 'error',
            'message': str(e),
            'error_type': e.__class__.__name__
        }