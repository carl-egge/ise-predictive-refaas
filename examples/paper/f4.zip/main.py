import json

def percentage_calculation(event, context):
    total = event.get('total', 0)
    percentage = event.get('percentage', 0)
    
    if total <= 0 or percentage < 0:
        return {
            'statusCode': 400,
            'body': json.dumps({'error': 'Invalid input'})
        }
    
    result = (percentage / 100) * total
    return {
        'statusCode': 200,
        'body': json.dumps({'result': result})
    }

def lambda_handler(event, context):
    return percentage_calculation(event, context)