import json

def fibonacci_sequence(event, context):
    n = event.get('n', 0)
    
    if n <= 0:
        return {
            'statusCode': 400,
            'body': json.dumps({'error': 'Invalid input'})
        }
    
    sequence = [0, 1]
    while len(sequence) < n:
        sequence.append(sequence[-1] + sequence[-2])
    
    return {
        'statusCode': 200,
        'body': json.dumps({'sequence': sequence})
    }

def lambda_handler(event, context):
    return fibonacci_sequence(event, context)