import json
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def log_decorator(func):
    def wrapper(event, context):
        logger.info(f"Function {func.__name__} called with event: {event}")
        return func(event, context)
    return wrapper

@log_decorator
def lambda_handler(event, context):
    return {
        'statusCode': 200,
        'body': json.dumps('Welcome to the Low Complexity Lambda Function!')
    }