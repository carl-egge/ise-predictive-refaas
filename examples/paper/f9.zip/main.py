import json
import logging
import requests

def lambda_handler(event, context):
    api_url = event.get('queryStringParameters', {}).get('url')

    if not api_url:
        return {
            "statusCode": 400,
            "body": json.dumps({"error": "Missing 'url' query parameter."})
        }

    try:
        response = requests.get(api_url)
        response.raise_for_status()
        data = response.json()
        print(f"Successfully fetched data from {api_url}")
        return {
            "statusCode": 200,
            "body": json.dumps(data)
        }
    except requests.exceptions.RequestException as e:
        print(f"HTTP Request failed: {e}")
        return {
            "statusCode": 500,
            "body": json.dumps({"error": "Failed to fetch data from the external API."})
        }