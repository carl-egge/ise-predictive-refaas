# 
# THIS FILE HAS BEEN CHANGE BY MATHIS KÄHLER
# 
# Copyright 2023 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the 'License');
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an 'AS IS' BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# [START chat_avatar_app]
import json

# The ID of the slash command "/about".
# It's not enabled by default, set to the actual ID to enable it. You need to
# use the same ID as set in the Google Chat API configuration.
ABOUT_COMMAND_ID = ""

def lambda_handler(event, context):
    print("test")
    if event['httpMethod'] == "GET":
        return {
            "statusCode": 200,
            "body": "Hello! This function must be called from Google Chat."
        }

    try:
        request_json = json.loads(event.get('body', '{}'))

        if "slashCommand" in request_json.get("message", {}):

            if request_json["message"]["slashCommand"].get("commandId") == ABOUT_COMMAND_ID:
                return {
                    "statusCode": 200,
                    "body": json.dumps({
                        "privateMessageViewer": request_json.get("user", {}),
                        "text": "The Avatar app replies to Google Chat messages."
                    })
                }
        # [END chat_avatar_slash_command]

        display_name = request_json["message"]["sender"].get("displayName", "User")
        avatar = request_json["message"]["sender"].get("avatarUrl", "")
        
        response = create_message(name=display_name, image_url=avatar)
        return {
            "statusCode": 200,
            "body": json.dumps(response)
        }

    except Exception as e:
        print(f"Error processing request: {e}, {e.__class__.__name__}")
        return {
            "statusCode": 400,
            "body": json.dumps({"error": str(e)})
        }


def create_message(name: str, image_url: str) -> dict:
    """Creates a response message with the user's avatar.

    Args:
        name (str): The sender's display name.
        image_url (str): The URL for the sender's avatar.

    Returns:
        dict: A card with the user's avatar.
    """
    return {
        "text": "Here's your avatar",
        "cardsV2": [{
            "cardId": "avatarCard",
            "card": {
                "name": "Avatar Card",
                "header": { "title": f"Hello {name}!" },
                "sections": [{
                    "widgets": [{
                        "textParagraph": { "text": "Your avatar picture:" }
                    }, {
                        "image": { "imageUrl": image_url }
                    }]
                }]
            }
        }]
    }