import json

def s056779272(input_data):
    input_lines = input_data.split('\n')
    input_iter = iter(input_lines)
    input = lambda: next(input_iter)
    
    import sys
    sys.setrecursionlimit(10 ** 6)
    n, m = map(int, input().split())
    edge = [tuple(map(int, input().split())) for _ in range(m)]
    connect = [set() for _ in range(n)]
    for a, b in edge:
        a -= 1
        b -= 1
        connect[a].add(b)
        connect[b].add(a)
    def search(cur, start):
        if start in connect[cur]:
            connect[cur].discard(start)
            connect[start].discard(cur)
        elif connect[cur] == set():
            return('No')
            exit()
        else:
            x = connect[cur].pop()
            connect[x].discard(cur)
            search(x, start)
    for _ in range(3):
        allset = True
        for s in connect:
            if s != set():
                allset = False
        if allset:
            return('No')
            exit()
        for a, b in edge:
            a -= 1
            b -= 1
            if a in connect[b]:
                connect[a].discard(b)
                connect[b].discard(a)
                search(a, b)
                break
    return('Yes')

def lambda_handler(event, context):
    input_data = event['body']
    
    result = s056779272(input_data)
    
    return {
        'statusCode': 200,
        'body': json.dumps(result)
    }
