package main

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"

	"github.com/aws/aws-lambda-go/events"
)

func handle(ctx context.Context, event json.RawMessage) (events.APIGatewayProxyResponse, error) {
	// Parse the event into a map to access fields
	var eventMap map[string]interface{}
	if err := json.Unmarshal(event, &eventMap); err != nil {
		return events.APIGatewayProxyResponse{
			StatusCode: http.StatusBadRequest,
			Body:       `{"error":"invalid input"}`,
		}, nil
	}

	// Extract query parameters
	queryParams, ok := eventMap["queryStringParameters"].(map[string]interface{})
	if !ok {
		queryParams = make(map[string]interface{})
	}

	city, ok := queryParams["city"].(string)
	if !ok || city == "" {
		return events.APIGatewayProxyResponse{
			StatusCode: http.StatusBadRequest,
			Body:       `{"error":"Missing 'city' query parameter."}`,
		}, nil
	}

	// Extract API_KEY
	apiKey, ok := eventMap["API_KEY"].(string)
	if !ok || apiKey == "" {
		return events.APIGatewayProxyResponse{
			StatusCode: http.StatusBadRequest,
			Body:       `{"error":"Missing 'API_KEY' environment variable."}`,
		}, nil
	}

	// Construct API URL
	apiURL := fmt.Sprintf("http://api.openweathermap.org/data/2.5/weather?q=%s&appid=%s&units=metric", city, apiKey)

	// Make HTTP request
	resp, err := http.Get(apiURL)
	if err != nil {
		return events.APIGatewayProxyResponse{
			StatusCode: http.StatusInternalServerError,
			Body:       `{"error":"Internal server error."}`,
		}, nil
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		body, _ := io.ReadAll(resp.Body)
		fmt.Printf("HTTP error occurred: %s\n", string(body))
		return events.APIGatewayProxyResponse{
			StatusCode: resp.StatusCode,
			Body:       `{"error":"Failed to fetch weather data."}`,
		}, nil
	}

	// Parse response body
	var weatherData map[string]interface{}
	if err := json.NewDecoder(resp.Body).Decode(&weatherData); err != nil {
		return events.APIGatewayProxyResponse{
			StatusCode: http.StatusInternalServerError,
			Body:       `{"error":"Internal server error."}`,
		}, nil
	}

	// Extract weather information
	weatherList, ok := weatherData["weather"].([]interface{})
	if !ok || len(weatherList) == 0 {
		return events.APIGatewayProxyResponse{
			StatusCode: http.StatusInternalServerError,
			Body:       `{"error":"Internal server error."}`,
		}, nil
	}

	weather, ok := weatherList[0].(map[string]interface{})
	if !ok {
		return events.APIGatewayProxyResponse{
			StatusCode: http.StatusInternalServerError,
			Body:       `{"error":"Internal server error."}`,
		}, nil
	}

	weatherDescription, ok := weather["description"].(string)
	if !ok {
		return events.APIGatewayProxyResponse{
			StatusCode: http.StatusInternalServerError,
			Body:       `{"error":"Internal server error."}`,
		}, nil
	}

	mainData, ok := weatherData["main"].(map[string]interface{})
	if !ok {
		return events.APIGatewayProxyResponse{
			StatusCode: http.StatusInternalServerError,
			Body:       `{"error":"Internal server error."}`,
		}, nil
	}

	temperature, ok := mainData["temp"].(float64)
	if !ok {
		return events.APIGatewayProxyResponse{
			StatusCode: http.StatusInternalServerError,
			Body:       `{"error":"Internal server error."}`,
		}, nil
	}

	humidity, ok := mainData["humidity"].(float64)
	if !ok {
		return events.APIGatewayProxyResponse{
			StatusCode: http.StatusInternalServerError,
			Body:       `{"error":"Internal server error."}`,
		}, nil
	}

	// Log the fetched weather data
	fmt.Printf("Fetched weather data for %s: %s, %.2f°C, %.0f%% humidity.\n", city, weatherDescription, temperature, humidity)

	// Prepare the result object
	result := map[string]interface{}{
		"city":                city,
		"weather_description": weatherDescription,
		"temperature_celsius": temperature,
		"humidity_percent":    humidity,
	}

	// Marshal the result to JSON
	body, err := json.Marshal(result)
	if err != nil {
		return events.APIGatewayProxyResponse{
			StatusCode: http.StatusInternalServerError,
			Body:       `{"error":"could not generate json"}`,
		}, nil
	}

	return events.APIGatewayProxyResponse{
		StatusCode: http.StatusOK,
		Body:       string(body),
	}, nil
}
