package main

import (
	"context"
	"encoding/json"
	"strconv"
	"strings"

	"github.com/aws/aws-lambda-go/events"
)

func handle(ctx context.Context, event json.RawMessage) (events.APIGatewayProxyResponse, error) {
	var request struct {
		Body string `json:"body"`
	}
	if err := json.Unmarshal(event, &request); err != nil {
		return events.APIGatewayProxyResponse{StatusCode: 400, Body: `{"error":"invalid input"}`}, nil
	}

	result := s056779272(request.Body)

	body, err := json.Marshal(result)
	if err != nil {
		return events.APIGatewayProxyResponse{StatusCode: 500, Body: `{"error":"could not generate json"}`}, nil
	}

	return events.APIGatewayProxyResponse{StatusCode: 200, Body: string(body)}, nil
}

func s056779272(inputData string) string {
	inputLines := strings.Split(inputData, "\n")
	inputIter := 0
	input := func() string {
		if inputIter >= len(inputLines) {
			return ""
		}
		line := inputLines[inputIter]
		inputIter++
		return line
	}

	nm := strings.Fields(input())
	if len(nm) < 2 {
		return "No"
	}
	n, _ := strconv.Atoi(nm[0])
	m, _ := strconv.Atoi(nm[1])

	edge := make([][2]int, m)
	for i := 0; i < m; i++ {
		fields := strings.Fields(input())
		if len(fields) < 2 {
			return "No"
		}
		a, _ := strconv.Atoi(fields[0])
		b, _ := strconv.Atoi(fields[1])
		edge[i] = [2]int{a, b}
	}

	connect := make([]map[int]struct{}, n)
	for i := range connect {
		connect[i] = make(map[int]struct{})
	}

	for _, e := range edge {
		a, b := e[0]-1, e[1]-1
		connect[a][b] = struct{}{}
		connect[b][a] = struct{}{}
	}

	var search func(cur, start int) string
	search = func(cur, start int) string {
		if _, ok := connect[cur][start]; ok {
			delete(connect[cur], start)
			delete(connect[start], cur)
		} else if len(connect[cur]) == 0 {
			return "No"
		} else {
			for x := range connect[cur] {
				delete(connect[x], cur)
				delete(connect[cur], x)
				res := search(x, start)
				if res == "No" {
					return "No"
				}
				break
			}
		}
		return ""
	}

	for i := 0; i < 3; i++ {
		allEmpty := true
		for _, s := range connect {
			if len(s) > 0 {
				allEmpty = false
				break
			}
		}
		if allEmpty {
			return "No"
		}

		for _, e := range edge {
			a, b := e[0]-1, e[1]-1
			if _, ok := connect[b][a]; ok {
				delete(connect[a], b)
				delete(connect[b], a)
				res := search(a, b)
				if res == "No" {
					return "No"
				}
				break
			}
		}
	}

	return "Yes"
}
