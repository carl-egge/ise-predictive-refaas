package main

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"

	"github.com/aws/aws-lambda-go/events"
)

func handle(ctx context.Context, event json.RawMessage) (events.APIGatewayProxyResponse, error) {
	var req struct {
		QueryStringParameters map[string]string `json:"queryStringParameters"`
	}
	if err := json.Unmarshal(event, &req); err != nil {
		return events.APIGatewayProxyResponse{
			StatusCode: http.StatusBadRequest,
			Body:       `{"error":"invalid input"}`,
		}, nil
	}

	apiURL := req.QueryStringParameters["url"]
	if apiURL == "" {
		return events.APIGatewayProxyResponse{
			StatusCode: http.StatusBadRequest,
			Body:       `{"error":"Missing 'url' query parameter."}`,
		}, nil
	}

	resp, err := http.Get(apiURL)
	if err != nil {
		fmt.Printf("HTTP Request failed: %v\n", err)
		return events.APIGatewayProxyResponse{
			StatusCode: http.StatusInternalServerError,
			Body:       `{"error":"Failed to fetch data from the external API."}`,
		}, nil
	}
	defer resp.Body.Close()

	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		fmt.Printf("HTTP Request failed: status code %d\n", resp.StatusCode)
		return events.APIGatewayProxyResponse{
			StatusCode: http.StatusInternalServerError,
			Body:       `{"error":"Failed to fetch data from the external API."}`,
		}, nil
	}

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		fmt.Printf("HTTP Request failed: %v\n", err)
		return events.APIGatewayProxyResponse{
			StatusCode: http.StatusInternalServerError,
			Body:       `{"error":"Failed to fetch data from the external API."}`,
		}, nil
	}

	fmt.Printf("Successfully fetched data from %s\n", apiURL)
	return events.APIGatewayProxyResponse{
		StatusCode: http.StatusOK,
		Body:       string(body),
	}, nil
}
