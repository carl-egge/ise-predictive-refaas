package main

import (
	"context"
	"encoding/json"
	"math"

	"github.com/aws/aws-lambda-go/events"
)

func handle(ctx context.Context, event json.RawMessage) (events.APIGatewayProxyResponse, error) {
	// Parse the event into a map to extract fields with defaults
	var eventMap map[string]interface{}
	if err := json.Unmarshal(event, &eventMap); err != nil {
		body, _ := json.Marshal(map[string]interface{}{"error": "Invalid input"})
		return events.APIGatewayProxyResponse{StatusCode: 400, Body: string(body)}, nil
	}

	// Extract parameters with defaults (0 if not provided)
	principal := 0.0
	if p, ok := eventMap["principal"].(float64); ok {
		principal = p
	} else if pInt, ok := eventMap["principal"].(int); ok {
		principal = float64(pInt)
	}

	rate := 0.0
	if r, ok := eventMap["rate"].(float64); ok {
		rate = r
	} else if rInt, ok := eventMap["rate"].(int); ok {
		rate = float64(rInt)
	}

	time := 0.0
	if t, ok := eventMap["time"].(float64); ok {
		time = t
	} else if tInt, ok := eventMap["time"].(int); ok {
		time = float64(tInt)
	}

	// Validate input parameters
	if principal <= 0 || rate < 0 || time < 0 {
		body, _ := json.Marshal(map[string]interface{}{"error": "Invalid input"})
		return events.APIGatewayProxyResponse{StatusCode: 400, Body: string(body)}, nil
	}

	// Calculate compound interest using the formula: A = P * (1 + r/100)^t
	result := principal * math.Pow(1+rate/100, time)

	// Return successful response with calculated result
	body, _ := json.Marshal(map[string]interface{}{"result": result})
	return events.APIGatewayProxyResponse{StatusCode: 200, Body: string(body)}, nil
}
