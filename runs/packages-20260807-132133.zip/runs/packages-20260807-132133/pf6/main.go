package main

import (
	"context"
	"encoding/json"
	"net/http"

	"github.com/aws/aws-lambda-go/events"
)

func handle(ctx context.Context, event json.RawMessage) (events.APIGatewayProxyResponse, error) {
	var input map[string]interface{}
	if err := json.Unmarshal(event, &input); err != nil {
		body, _ := json.Marshal(map[string]interface{}{"error": "Invalid input"})
		return events.APIGatewayProxyResponse{StatusCode: http.StatusBadRequest, Body: string(body)}, nil
	}

	n, ok := input["n"].(float64)
	if !ok {
		body, _ := json.Marshal(map[string]interface{}{"error": "Invalid input"})
		return events.APIGatewayProxyResponse{StatusCode: http.StatusBadRequest, Body: string(body)}, nil
	}

	if n <= 0 {
		body, _ := json.Marshal(map[string]interface{}{"error": "Invalid input"})
		return events.APIGatewayProxyResponse{StatusCode: http.StatusBadRequest, Body: string(body)}, nil
	}

	sequence := []int{0, 1}
	for len(sequence) < int(n) {
		next := sequence[len(sequence)-1] + sequence[len(sequence)-2]
		sequence = append(sequence, next)
	}

	body, _ := json.Marshal(map[string]interface{}{"sequence": sequence})
	return events.APIGatewayProxyResponse{StatusCode: http.StatusOK, Body: string(body)}, nil
}
