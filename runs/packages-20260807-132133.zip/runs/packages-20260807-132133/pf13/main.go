package main

import (
	"context"
	"encoding/json"
	"log"
	"os"

	"github.com/aws/aws-lambda-go/events"
)

// Initialize logger for the Lambda function
var logger = log.New(os.Stdout, "", log.LstdFlags)

func handle(ctx context.Context, event json.RawMessage) (events.APIGatewayProxyResponse, error) {
	// Log the function name and input event for debugging/tracing
	logger.Printf("Function handle called with event: %s", string(event))

	// Return a simple welcome message with HTTP 200 status
	body := `"Welcome to the Low Complexity Lambda Function!"`

	return events.APIGatewayProxyResponse{
		StatusCode: 200,
		Body:       body,
	}, nil
}
