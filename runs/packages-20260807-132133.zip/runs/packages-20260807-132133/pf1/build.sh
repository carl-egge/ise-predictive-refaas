#! /bin/sh

go mod init example.com
go mod tidy
go build -o fn .
