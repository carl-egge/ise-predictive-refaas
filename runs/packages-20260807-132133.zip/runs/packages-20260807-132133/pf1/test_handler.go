package main

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"os"
)

func main() {
	input, err := io.ReadAll(os.Stdin)
	if err != nil {
		log.Fatalf("Failed to read input: %v", err)
	}

	ctx := context.Background()
	response, err := handle(ctx, json.RawMessage(input))

	output := make(map[string]interface{})
	if err != nil {
		output["error"] = err.Error()
	} else {
		output["response"] = response
	}

	outputJSON, err := json.MarshalIndent(output, "", "  ")
	if err != nil {
		log.Fatalf("Failed to marshal output: %v", err)
	}

	fmt.Println(string(outputJSON))
}
