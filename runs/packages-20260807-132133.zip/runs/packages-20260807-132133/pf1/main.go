package main

import (
	"context"
	"encoding/json"

	"github.com/aws/aws-lambda-go/events"
)

func handle(ctx context.Context, event json.RawMessage) (events.APIGatewayProxyResponse, error) {
	body, err := json.Marshal(map[string]interface{}{"message": "hello world"})
	if err != nil {
		return events.APIGatewayProxyResponse{
			StatusCode: 500,
			Body:       `{"error":"could not generate json"}`,
		}, nil
	}
	return events.APIGatewayProxyResponse{
		StatusCode: 200,
		Body:       string(body),
	}, nil
}
