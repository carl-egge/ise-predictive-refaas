package main

import (
	"context"
	"encoding/json"
	"net/http"

	"github.com/aws/aws-lambda-go/events"
)

func handle(ctx context.Context, event json.RawMessage) (events.APIGatewayProxyResponse, error) {
	// Parse the event into a map to access 'body' field
	var eventMap map[string]interface{}
	if err := json.Unmarshal(event, &eventMap); err != nil {
		return events.APIGatewayProxyResponse{
			StatusCode: http.StatusInternalServerError,
			Body:       `{"error":"Internal server error."}`,
		}, nil
	}

	// Get the body string, defaulting to empty object if missing
	bodyStr, ok := eventMap["body"].(string)
	if !ok {
		bodyStr = "{}"
	}

	// Parse the JSON body
	var body map[string]interface{}
	if err := json.Unmarshal([]byte(bodyStr), &body); err != nil {
		return events.APIGatewayProxyResponse{
			StatusCode: http.StatusBadRequest,
			Body:       `{"error":"Invalid JSON format."}`,
		}, nil
	}

	// Extract user information
	user, ok := body["user"].(map[string]interface{})
	if !ok {
		user = make(map[string]interface{})
	}

	name, _ := user["name"].(string)
	contact, ok := user["contact"].(map[string]interface{})
	if !ok {
		contact = make(map[string]interface{})
	}
	email, _ := contact["email"].(string)

	// Validate required fields
	if name == "" || email == "" {
		return events.APIGatewayProxyResponse{
			StatusCode: http.StatusBadRequest,
			Body:       `{"error":"Missing user information: name and email are required."}`,
		}, nil
	}

	// Prepare successful response
	result := map[string]interface{}{
		"name":  name,
		"email": email,
	}

	responseBody, err := json.Marshal(result)
	if err != nil {
		return events.APIGatewayProxyResponse{
			StatusCode: http.StatusInternalServerError,
			Body:       `{"error":"Internal server error."}`,
		}, nil
	}

	return events.APIGatewayProxyResponse{
		StatusCode: http.StatusOK,
		Body:       string(responseBody),
	}, nil
}
