package main

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"

	"github.com/aws/aws-lambda-go/events"
)

// ABOUT_COMMAND_ID is the ID of the slash command "/about".
// It's not enabled by default, set to the actual ID to enable it.
const ABOUT_COMMAND_ID = ""

// handle is the main handler function for the AWS Lambda that processes Google Chat webhook events.
func handle(ctx context.Context, event json.RawMessage) (events.APIGatewayProxyResponse, error) {
	// Parse the event into a map to access fields
	var eventMap map[string]interface{}
	if err := json.Unmarshal(event, &eventMap); err != nil {
		return events.APIGatewayProxyResponse{
			StatusCode: http.StatusBadRequest,
			Body:       `{"error":"invalid input"}`,
		}, nil
	}

	// Handle GET requests - typically used for health checks or verification
	if httpMethod, ok := eventMap["httpMethod"].(string); ok && httpMethod == "GET" {
		return events.APIGatewayProxyResponse{
			StatusCode: http.StatusOK,
			Body:       "Hello! This function must be called from Google Chat.",
		}, nil
	}

	// Parse the incoming request body as JSON
	var requestBody map[string]interface{}
	bodyStr, _ := eventMap["body"].(string)
	if bodyStr == "" {
		bodyStr = "{}"
	}
	if err := json.Unmarshal([]byte(bodyStr), &requestBody); err != nil {
		return events.APIGatewayProxyResponse{
			StatusCode: http.StatusBadRequest,
			Body:       `{"error":"invalid input"}`,
		}, nil
	}

	// Check if the message contains a slash command
	if message, ok := requestBody["message"].(map[string]interface{}); ok {
		if slashCommand, ok := message["slashCommand"].(map[string]interface{}); ok {
			// Handle the "/about" slash command if configured
			if commandID, ok := slashCommand["commandId"].(string); ok && commandID == ABOUT_COMMAND_ID {
				user := requestBody["user"]
				if user == nil {
					user = map[string]interface{}{}
				}
				response := map[string]interface{}{
					"privateMessageViewer": user,
					"text":                 "The Avatar app replies to Google Chat messages.",
				}
				body, err := json.Marshal(response)
				if err != nil {
					return events.APIGatewayProxyResponse{
						StatusCode: http.StatusInternalServerError,
						Body:       `{"error":"could not generate json"}`,
					}, nil
				}
				return events.APIGatewayProxyResponse{
					StatusCode: http.StatusOK,
					Body:       string(body),
				}, nil
			}
		}
	}

	// Extract sender information from the message
	var displayName, avatarURL string
	if message, ok := requestBody["message"].(map[string]interface{}); ok {
		if sender, ok := message["sender"].(map[string]interface{}); ok {
			if name, ok := sender["displayName"].(string); ok {
				displayName = name
			} else {
				displayName = "User"
			}
			if avatar, ok := sender["avatarUrl"].(string); ok {
				avatarURL = avatar
			}
		} else {
			// If sender is missing, return an error
			return events.APIGatewayProxyResponse{
				StatusCode: http.StatusBadRequest,
				Body:       `{"error": "'sender'"}`,
			}, nil
		}
	} else {
		// If message is missing, return an error
		return events.APIGatewayProxyResponse{
			StatusCode: http.StatusBadRequest,
			Body:       `{"error": "'message'"}`,
		}, nil
	}

	// Create and return an avatar card response
	response := createMessage(displayName, avatarURL)
	body, err := json.Marshal(response)
	if err != nil {
		return events.APIGatewayProxyResponse{
			StatusCode: http.StatusInternalServerError,
			Body:       `{"error":"could not generate json"}`,
		}, nil
	}
	return events.APIGatewayProxyResponse{
		StatusCode: http.StatusOK,
		Body:       string(body),
	}, nil
}

// createMessage creates a response message with the user's avatar.
func createMessage(name string, imageURL string) map[string]interface{} {
	return map[string]interface{}{
		"text": "Here's your avatar",
		"cardsV2": []map[string]interface{}{
			{
				"cardId": "avatarCard",
				"card": map[string]interface{}{
					"name": "Avatar Card",
					"header": map[string]interface{}{
						"title": fmt.Sprintf("Hello %s!", name),
					},
					"sections": []map[string]interface{}{
						{
							"widgets": []map[string]interface{}{
								{
									"textParagraph": map[string]interface{}{
										"text": "Your avatar picture:",
									},
								},
								{
									"image": map[string]interface{}{
										"imageUrl": imageURL,
									},
								},
							},
						},
					},
				},
			},
		},
	}
}
