package main

import (
	"context"
	"encoding/json"
	"net/http"

	"github.com/aws/aws-lambda-go/events"
)

func countEmployees(department map[string]interface{}) int {
	employees := 0
	if emp, ok := department["employees"].(float64); ok {
		employees = int(emp)
	}

	subDepts, ok := department["sub_departments"].([]interface{})
	if !ok {
		subDepts = []interface{}{}
	}

	for _, sub := range subDepts {
		if subDept, ok := sub.(map[string]interface{}); ok {
			employees += countEmployees(subDept)
		}
	}

	department["total_employees"] = employees
	return employees
}

func handle(ctx context.Context, event json.RawMessage) (events.APIGatewayProxyResponse, error) {
	var req struct {
		Body string `json:"body"`
	}
	if err := json.Unmarshal(event, &req); err != nil {
		return events.APIGatewayProxyResponse{
			StatusCode: http.StatusInternalServerError,
			Body:       `{"error":"the JSON object must be str, bytes or bytearray, not NoneType"}`,
		}, nil
	}

	var body map[string]interface{}
	if err := json.Unmarshal([]byte(req.Body), &body); err != nil {
		return events.APIGatewayProxyResponse{
			StatusCode: http.StatusInternalServerError,
			Body:       `{"error":"` + err.Error() + `"}`,
		}, nil
	}

	orgStruct, ok := body["org_structure"].(map[string]interface{})
	if !ok {
		return events.APIGatewayProxyResponse{
			StatusCode: http.StatusBadRequest,
			Body:       `{"error":"Missing \"org_structure\" in request body."}`,
		}, nil
	}

	depts, ok := orgStruct["departments"].([]interface{})
	if !ok {
		depts = []interface{}{}
	}

	for _, dept := range depts {
		if d, ok := dept.(map[string]interface{}); ok {
			countEmployees(d)
		}
	}

	respBody, err := json.Marshal(map[string]interface{}{"org_structure": orgStruct})
	if err != nil {
		return events.APIGatewayProxyResponse{
			StatusCode: http.StatusInternalServerError,
			Body:       `{"error":"could not generate json"}`,
		}, nil
	}

	return events.APIGatewayProxyResponse{
		StatusCode: http.StatusOK,
		Body:       string(respBody),
	}, nil
}
