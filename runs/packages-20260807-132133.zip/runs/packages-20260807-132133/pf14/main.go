package main

import (
	"context"
	"encoding/json"
	"fmt"
	"strings"
	"time"

	"github.com/aws/aws-lambda-go/events"
)

type ComplexDataProcessor struct{}

func (p *ComplexDataProcessor) reverse(s string) string {
	runes := []rune(s)
	for i, j := 0, len(runes)-1; i < j; i, j = i+1, j-1 {
		runes[i], runes[j] = runes[j], runes[i]
	}
	return string(runes)
}

func (p *ComplexDataProcessor) uppercase(s string) string {
	return strings.ToUpper(s)
}

func (p *ComplexDataProcessor) timestamp() string {
	return time.Now().UTC().Format("2006-01-02T15:04:05.999999")
}

func (p *ComplexDataProcessor) processComplexData(data map[string]interface{}) ([]map[string]interface{}, error) {
	// Validate input structure
	if _, ok := data["id"]; !ok {
		return nil, fmt.Errorf("Invalid input structure")
	}
	if _, ok := data["timestamp"]; !ok {
		return nil, fmt.Errorf("Invalid input structure")
	}

	results := make([]map[string]interface{}, 0)

	// Stage 1: Transform the ID by reversing it
	results = append(results, map[string]interface{}{
		"stage":     "id_transform",
		"value":     p.reverse(data["id"].(string)),
		"timestamp": p.timestamp(),
	})

	// Stage 2: Generate a sequence of transformed items
	for i := 0; i < 3; i++ {
		results = append(results, map[string]interface{}{
			"stage":       "sequence",
			"data":        map[string]interface{}{"index": i, "value": p.uppercase(fmt.Sprintf("%d", i))},
			"original_id": data["id"],
			"timestamp":   p.timestamp(),
		})
	}

	// Stage 3: Create the final result with all processed data
	finalResult := map[string]interface{}{
		"final":          true,
		"transformed_id": fmt.Sprintf("PROC_%s", data["id"]),
		"metadata": map[string]interface{}{
			"original":    data,
			"processTime": p.timestamp(),
		},
	}
	results = append(results, finalResult)

	return results, nil
}

func handle(ctx context.Context, event json.RawMessage) (events.APIGatewayProxyResponse, error) {
	var input map[string]interface{}
	if err := json.Unmarshal(event, &input); err != nil {
		return events.APIGatewayProxyResponse{
			StatusCode: 400,
			Body:       `{"error":"invalid input"}`,
		}, nil
	}

	// Validate input structure
	if _, ok := input["id"]; !ok {
		response := map[string]interface{}{
			"status":     "error",
			"message":    "Invalid input structure",
			"error_type": "ValueError",
		}
		body, _ := json.Marshal(response)
		return events.APIGatewayProxyResponse{
			StatusCode: 200,
			Body:       string(body),
		}, nil
	}
	if _, ok := input["timestamp"]; !ok {
		response := map[string]interface{}{
			"status":     "error",
			"message":    "Invalid input structure",
			"error_type": "ValueError",
		}
		body, _ := json.Marshal(response)
		return events.APIGatewayProxyResponse{
			StatusCode: 200,
			Body:       string(body),
		}, nil
	}

	processor := &ComplexDataProcessor{}
	results, err := processor.processComplexData(input)

	if err != nil {
		response := map[string]interface{}{
			"status":     "error",
			"message":    err.Error(),
			"error_type": "ValueError",
		}
		body, _ := json.Marshal(response)
		return events.APIGatewayProxyResponse{
			StatusCode: 200,
			Body:       string(body),
		}, nil
	}

	response := map[string]interface{}{
		"status": "success",
		"data":   results,
		"metadata": map[string]interface{}{
			"processed_at":     time.Now().UTC().Format("2006-01-02T15:04:05.999999"),
			"stages_completed": len(results),
		},
	}

	body, err := json.Marshal(response)
	if err != nil {
		return events.APIGatewayProxyResponse{
			StatusCode: 500,
			Body:       `{"error":"could not generate json"}`,
		}, nil
	}

	return events.APIGatewayProxyResponse{
		StatusCode: 200,
		Body:       string(body),
	}, nil
}
