package main

import (
	"context"
	"encoding/json"
	"net/http"

	"github.com/aws/aws-lambda-go/events"
)

func handle(ctx context.Context, event json.RawMessage) (events.APIGatewayProxyResponse, error) {
	var input struct {
		Total      float64 `json:"total"`
		Percentage float64 `json:"percentage"`
	}

	if err := json.Unmarshal(event, &input); err != nil {
		body, _ := json.Marshal(map[string]interface{}{"error": "Invalid input"})
		return events.APIGatewayProxyResponse{StatusCode: http.StatusBadRequest, Body: string(body)}, nil
	}

	total := input.Total
	percentage := input.Percentage

	if total <= 0 || percentage < 0 {
		body, _ := json.Marshal(map[string]interface{}{"error": "Invalid input"})
		return events.APIGatewayProxyResponse{StatusCode: http.StatusBadRequest, Body: string(body)}, nil
	}

	result := (percentage / 100) * total
	body, _ := json.Marshal(map[string]interface{}{"result": result})
	return events.APIGatewayProxyResponse{StatusCode: http.StatusOK, Body: string(body)}, nil
}
