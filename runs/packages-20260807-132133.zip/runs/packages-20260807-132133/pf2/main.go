package main

import (
	"context"
	"encoding/json"
	"net/http"

	"github.com/aws/aws-lambda-go/events"
)

func handle(ctx context.Context, event json.RawMessage) (events.APIGatewayProxyResponse, error) {
	var request struct {
		Num1 float64 `json:"num1"`
		Num2 float64 `json:"num2"`
	}
	if err := json.Unmarshal(event, &request); err != nil {
		return events.APIGatewayProxyResponse{StatusCode: http.StatusBadRequest, Body: `{"error":"invalid input"}`}, nil
	}

	result := request.Num1 + request.Num2
	body, err := json.Marshal(map[string]interface{}{"result": result})
	if err != nil {
		return events.APIGatewayProxyResponse{StatusCode: http.StatusInternalServerError, Body: `{"error":"could not generate json"}`}, nil
	}

	return events.APIGatewayProxyResponse{StatusCode: http.StatusOK, Body: string(body)}, nil
}
