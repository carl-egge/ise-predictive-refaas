package main

import (
	"context"
	"encoding/json"
	"net/http"

	"github.com/aws/aws-lambda-go/events"
)

func handle(ctx context.Context, event json.RawMessage) (events.APIGatewayProxyResponse, error) {
	var input map[string]interface{}
	if err := json.Unmarshal(event, &input); err != nil {
		body, _ := json.Marshal(map[string]interface{}{"error": "invalid input"})
		return events.APIGatewayProxyResponse{StatusCode: http.StatusBadRequest, Body: string(body)}, nil
	}

	num1 := 0.0
	num2 := 0.0
	operation := "@"

	if v, ok := input["num1"].(float64); ok {
		num1 = v
	} else if v, ok := input["num1"].(int); ok {
		num1 = float64(v)
	}

	if v, ok := input["num2"].(float64); ok {
		num2 = v
	} else if v, ok := input["num2"].(int); ok {
		num2 = float64(v)
	}

	if v, ok := input["operation"].(string); ok {
		operation = v
	}

	var result float64
	switch operation {
	case "+":
		result = num1 + num2
	case "-":
		result = num1 - num2
	case "*":
		result = num1 * num2
	case "/":
		if num2 == 0 {
			body, _ := json.Marshal(map[string]interface{}{"error": "Division by zero"})
			return events.APIGatewayProxyResponse{StatusCode: http.StatusBadRequest, Body: string(body)}, nil
		}
		result = num1 / num2
	default:
		body, _ := json.Marshal(map[string]interface{}{"error": "Invalid operation"})
		return events.APIGatewayProxyResponse{StatusCode: http.StatusBadRequest, Body: string(body)}, nil
	}

	body, _ := json.Marshal(map[string]interface{}{"result": result})
	return events.APIGatewayProxyResponse{StatusCode: http.StatusOK, Body: string(body)}, nil
}
